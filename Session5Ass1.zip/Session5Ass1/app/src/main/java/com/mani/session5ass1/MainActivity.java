package com.mani.session5ass1;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener {
TextView tvsearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvsearch=(TextView)findViewById(R.id.tvsearch);
        tvsearch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent searchintent=new Intent(Intent.ACTION_WEB_SEARCH);
        searchintent.putExtra(SearchManager.QUERY,"Android Material");
        startActivity(searchintent);
    }
}
